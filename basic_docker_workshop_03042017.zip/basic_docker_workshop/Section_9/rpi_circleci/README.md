#CircleCI for ARM Raspbian Demo

##Reference
1. [2016 COSCUP Advanced Docker Workshop](https://github.com/philipz/docker_workshop)
2. [Uniform Development by Docker & QEMU](http://www.instructables.com/id/Uniform-Development-by-Docker-QEMU/)
3. [Building ARM containers on any x86 machine, even DockerHub](https://resin.io/blog/building-arm-containers-on-any-x86-machine-even-dockerhub/)

Combind Docker Compose & CircleCI for ARM device automatic testing.
