#!/bin/bash
mono HelloWorld.exe
