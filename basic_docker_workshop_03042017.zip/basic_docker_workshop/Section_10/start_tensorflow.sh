nvidia-docker run -it --rm -p 8888:8888 tensorflow/tensorflow:latest-gpu
